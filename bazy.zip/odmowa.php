<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
<header></header>
<main>
    <div id="form">
    <p>NIEPOPRAWNE DANE</p>
    <form action="index.php" method="POST">
    <p><input type="submit" value="Powrót" class="button1"></p>
    </form>
    </div>
    </main>
    <footer><p class ="licencja">Image by <a href="https://www.freepik.com/free-vector/gradient-geometric-shapes-dark-background_6674351.htm#page=3&query=modern%20background%20abstract&position=20&from_view=keyword">Freepik</a></p></footer>    
</body>
</html>